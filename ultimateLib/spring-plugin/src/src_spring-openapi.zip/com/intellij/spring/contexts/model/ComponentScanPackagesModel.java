/*
 * Copyright 2000-2014 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.spring.contexts.model;

import com.intellij.openapi.module.Module;
import com.intellij.openapi.util.NotNullLazyValue;
import com.intellij.psi.PsiFile;
import com.intellij.psi.PsiPackage;
import com.intellij.psi.search.GlobalSearchScope;
import com.intellij.psi.search.PackageScope;
import com.intellij.spring.model.BeanService;
import com.intellij.spring.model.CommonSpringBean;
import com.intellij.spring.model.SpringBeanPointer;
import com.intellij.spring.model.jam.SpringJamModel;
import com.intellij.spring.model.jam.javaConfig.SpringJavaBean;
import com.intellij.spring.model.jam.stereotype.SpringConfiguration;
import com.intellij.spring.model.jam.stereotype.SpringStereotypeElement;
import com.intellij.spring.model.jam.utils.SpringJamUtils;
import com.intellij.spring.model.jam.utils.filters.SpringContextFilter;
import com.intellij.spring.model.utils.SpringProfileUtils;
import com.intellij.spring.model.xml.context.SpringBeansPackagesScan;
import com.intellij.util.NotNullFunction;
import com.intellij.util.containers.ContainerUtil;
import com.intellij.util.containers.HashSet;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;

public class ComponentScanPackagesModel extends AbstractSimpleSpringModel {

  private final NotNullLazyValue<Set<PsiPackage>> myPackages;

  @NotNull
  private final Module myModule;

  public ComponentScanPackagesModel(@NotNull NotNullLazyValue<Set<PsiPackage>> packages, @NotNull Module module) {
    myPackages = packages;
    myModule = module;
  }

  @Override
  protected final Collection<SpringBeanPointer> calculateLocalBeans() {
    Collection<SpringBeanPointer> pointers = calculateScannedBeans();

    Set<SpringJavaBean> javaBeans =ContainerUtil.newHashSet();
    for (SpringBeanPointer pointer : pointers) {
      CommonSpringBean springBean = pointer.getSpringBean();
      if (springBean instanceof SpringConfiguration) continue;
      if (springBean instanceof SpringStereotypeElement) {
        javaBeans.addAll(((SpringStereotypeElement)springBean).getBeans());
      }
    }

    Set<SpringBeanPointer> beans = ContainerUtil.newHashSet();
    beans.addAll(pointers);
    beans.addAll( BeanService.getInstance().mapSpringBeans(javaBeans));

    return beans;
  }

  protected Collection<SpringBeanPointer> calculateScannedBeans() {
    return getScannedComponents(myPackages.getValue(), getModule(), getActiveProfiles());
  }

  public static Collection<SpringBeanPointer> getScannedComponents(@NotNull Set<PsiPackage> packages,
                                                                   @NotNull Module module,
                                                                   @Nullable Set<String> profiles) {
    return getScannedComponents(packages, module, profiles, true,
                                Collections.<SpringContextFilter.Exclude>emptySet(),
                                Collections.<SpringContextFilter.Include>emptySet());
  }

  public static Collection<SpringConfiguration> getScannedConfigurations(SpringBeansPackagesScan scan,
                                                                   @NotNull final Module module,
                                                                   @Nullable Set<String> profiles) {

    List<CommonSpringBean> components = getScannedComponents(new NotNullFunction<GlobalSearchScope, List<SpringConfiguration>>() {
                                                               @NotNull
                                                               @Override
                                                               public List<SpringConfiguration> fun(GlobalSearchScope dom) {
                                                                 return SpringJamModel.getModel(module).getConfigurations(dom);
                                                               }
                                                             },
                                                             scan.getPsiPackages(), module, profiles, scan.useDefaultFilters(),
                                                             scan.getExcludeContextFilters(),
                                                             scan.getIncludeContextFilters());

    Set<SpringConfiguration> configurations = new LinkedHashSet<SpringConfiguration>();
    for (CommonSpringBean component : components) {
      if (component instanceof SpringConfiguration) {
        configurations.add((SpringConfiguration)component);
      }
    }
    return configurations;
  }
  public static Collection<SpringBeanPointer> getScannedComponents(@NotNull Set<PsiPackage> packages,
                                                                   @NotNull final Module module,
                                                                   @Nullable Set<String> profiles,
                                                                   boolean useDefaultFilters,
                                                                   @NotNull Set<SpringContextFilter.Exclude> excludeContextFilters,
                                                                   @NotNull Set<SpringContextFilter.Include> includeContextFilters) {
    Collection<CommonSpringBean> components =
      getScannedComponents(new NotNullFunction<GlobalSearchScope, List<SpringStereotypeElement>>() {
        @NotNull
        @Override
        public List<SpringStereotypeElement> fun(GlobalSearchScope dom) {
          return SpringJamModel.getModel(module).getStereotypeComponents(dom);
        }
      }, packages, module, profiles, useDefaultFilters, excludeContextFilters, includeContextFilters);

     return BeanService.getInstance().mapSpringBeans(components);
  }

  public static <T extends SpringStereotypeElement> List<CommonSpringBean> getScannedComponents(@NotNull NotNullFunction<GlobalSearchScope, List<T>> components,
                                                                                                @NotNull Set<PsiPackage> packages,
                                                                                                @NotNull Module module,
                                                                                                @Nullable Set<String> profiles,
                                                                                                boolean useDefaultFilters,
                                                                                                @NotNull Set<SpringContextFilter.Exclude> excludeContextFilters,
                                                                                                @NotNull Set<SpringContextFilter.Include> includeContextFilters) {
    if (module.isDisposed()) return ContainerUtil.newArrayList();

    final GlobalSearchScope moduleScope = GlobalSearchScope.moduleWithDependenciesAndLibrariesScope(module);
    final List<CommonSpringBean> allPointers = new ArrayList<CommonSpringBean>();
    final Set<PsiPackage> notNullPackages = new HashSet<PsiPackage>();
    for (PsiPackage psiPackage : packages) {
      if (psiPackage != null) {
        notNullPackages.add(psiPackage);
        final GlobalSearchScope searchScope = moduleScope.intersectWith(PackageScope.packageScope(psiPackage, true));
        for (SpringStereotypeElement stereotypeElement : components.fun(searchScope)){
          allPointers.add(stereotypeElement);
        }
      }
    }

    Set<CommonSpringBean> filteredBeans =
      SpringJamUtils.getInstance().filterComponentScannedStereotypes(module, allPointers, notNullPackages, useDefaultFilters,
                                                                     excludeContextFilters, includeContextFilters);

    return  SpringProfileUtils.filterBeansInActiveProfiles(filteredBeans, profiles);
  }

  @NotNull
  @Override
  public Module getModule() {
    return myModule;
  }

  @NotNull
  @Override
  public Set<String> getAllProfiles() {
    return Collections.emptySet();
  }

  @NotNull
  @Override
  public Set<PsiFile> getConfigFiles() {
    return Collections.emptySet();
  }

  @Override
  public boolean hasConfigFile(@NotNull PsiFile configFile) {
    return false;
  }
}
