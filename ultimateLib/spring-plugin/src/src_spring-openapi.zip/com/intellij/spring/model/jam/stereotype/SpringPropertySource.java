/*
 * Copyright 2000-2014 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.spring.model.jam.stereotype;

import com.intellij.jam.JamElement;
import com.intellij.jam.JamStringAttributeElement;
import com.intellij.jam.annotations.JamPsiConnector;
import com.intellij.jam.reflect.JamAnnotationMeta;
import com.intellij.jam.reflect.JamAttributeMeta;
import com.intellij.jam.reflect.JamClassMeta;
import com.intellij.jam.reflect.JamStringAttributeMeta;
import com.intellij.lang.properties.psi.PropertiesFile;
import com.intellij.psi.PsiAnnotation;
import com.intellij.psi.PsiClass;
import com.intellij.spring.constants.SpringAnnotationsConstants;
import com.intellij.spring.model.jam.converters.PropertiesFileConverter;
import com.intellij.util.containers.hash.HashSet;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Set;

public class SpringPropertySource implements JamElement {

  private static final JamStringAttributeMeta.Collection<Set<PropertiesFile>> VALUE_ATTR_META =
    JamAttributeMeta.collectionString("value", new PropertiesFileConverter());

  private static final JamAnnotationMeta ANNO_META =
    new JamAnnotationMeta(SpringAnnotationsConstants.PROPERTY_SOURCE).
      addAttribute(VALUE_ATTR_META);

  public static final JamClassMeta<SpringPropertySource> META =
    new JamClassMeta<SpringPropertySource>(SpringPropertySource.class).
      addAnnotation(ANNO_META);

  private final PsiClass myPsiClass;

  public SpringPropertySource(@NotNull PsiClass psiClass) {
    myPsiClass = psiClass;
  }

  @NotNull
  @JamPsiConnector
  public PsiClass getPsiElement() {
    return myPsiClass;
  }

  public boolean isPsiValid() {
    return myPsiClass.isValid();
  }

  @Nullable
  public PsiAnnotation getAnnotation() {
    return ANNO_META.getAnnotation(getPsiElement());
  }

  public Set<PropertiesFile> getPropertiesFiles() {
    Set<PropertiesFile> propertiesFiles = new HashSet<PropertiesFile>();

    final List<JamStringAttributeElement<Set<PropertiesFile>>> attributeValues =
      ANNO_META.getAttribute(getPsiElement(), VALUE_ATTR_META);

    for (JamStringAttributeElement<Set<PropertiesFile>> attributeElement : attributeValues) {
      final Set<PropertiesFile> value = attributeElement.getValue();
      if (value != null) propertiesFiles.addAll(value);
    }

    return propertiesFiles;
  }
}
