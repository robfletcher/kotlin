/*
 * Copyright 2000-2015 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.spring.model.jam.utils;

import com.intellij.jam.model.common.CommonModelElement;
import com.intellij.openapi.components.ServiceManager;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.util.Pair;
import com.intellij.psi.PsiClass;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiPackage;
import com.intellij.psi.xml.XmlFile;
import com.intellij.spring.CommonSpringModel;
import com.intellij.spring.contexts.model.LocalAnnotationModel;
import com.intellij.spring.contexts.model.LocalModel;
import com.intellij.spring.contexts.model.graph.LocalModelDependency;
import com.intellij.spring.model.CommonSpringBean;
import com.intellij.spring.model.SpringBeanPointer;
import com.intellij.spring.model.jam.javaConfig.ContextJavaBean;
import com.intellij.spring.model.jam.stereotype.SpringPropertySource;
import com.intellij.spring.model.jam.stereotype.SpringStereotypeElement;
import com.intellij.spring.model.jam.utils.filters.SpringContextFilter;
import com.intellij.spring.model.xml.context.SpringBeansPackagesScan;
import com.intellij.util.PairProcessor;
import com.intellij.util.Processor;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Set;

/**
 * @author Yann C&eacute;bron
 */
public abstract class SpringJamUtils {

  public static SpringJamUtils getInstance() {
    return ServiceManager.getService(SpringJamUtils.class);
  }

  /**
   * @Bean-annotated beans.
   */
  @NotNull
  public abstract List<ContextJavaBean> getContextBeans(@NotNull PsiClass beanClass,
                                                        @Nullable Set<String> activeProfiles);

  /**
   * XML config files defined with @ImportResource annotations.
   */
  @NotNull
  public abstract Set<XmlFile> getImportedResources(@NotNull PsiClass psiClass);

  /**
   * Processes {@code @ImportResource} annotation. For each element of annotation value XML config files defined by this element and
   * PsiElement defining this element are passed to processor.
   *
   * @param psiClass  Class with {@code @ImportResource} annotation to process.
   * @param processor Processor, both pair elements are guaranteed to be non-{@code null}.
   */
  public abstract boolean processImportedResources(@NotNull PsiClass psiClass,
                                                   @NotNull Processor<Pair<List<XmlFile>, ? extends PsiElement>> processor);

  /**
   * Classes (@Configuration) defined with @Import annotations.
   */
  @NotNull
  public abstract Set<PsiClass> getImportedClasses(@NotNull PsiClass clazz,
                                                   @Nullable Module module);

  /**
   * Processes {@code @Import} annotation. For each element of annotation value Java config files defined by this element and
   * PsiElement defining this element are passed to processor.
   *
   * @param clazz     Class with {@code @Import} annotation to process.
   * @param processor Processor, both pair elements are guaranteed to be non-{@code null}.
   */
  public abstract boolean processImportedClasses(@NotNull PsiClass clazz,
                                                 @NotNull Processor<Pair<PsiClass, ? extends PsiElement>> processor);

  /**
   * Component scans (@ComponentScan).
   */
  @NotNull
  public abstract List<SpringBeansPackagesScan> getComponentScans(@NotNull PsiClass psiClass);

  /**
   * @PropertySource annotated.
   */
  @Nullable
  public abstract SpringPropertySource getSpringPropertySource(@NotNull PsiClass psiClass);

  /**
   * Search configuration beans (<component-scan/>, @ComponentScan, @Repositories, etc.)
   * which loaded beans (beansInModel parameter) in model.
   */
  @NotNull
  public abstract Set<CommonModelElement> findStereotypeConfigurationBeans(@NotNull CommonSpringModel model,
                                                                           @NotNull List<? extends SpringBeanPointer> beansInModel,
                                                                           @Nullable Module module);

  /**
   * Filter components loaded by componentScan (analyses packages, include/exclude filters).
   */
  @NotNull
  public abstract Set<CommonSpringBean> filterComponentScannedStereotypes(@NotNull Module module,
                                                                          @NotNull SpringBeansPackagesScan componentScan,
                                                                          @NotNull List<? extends CommonSpringBean> allComponents);


  public abstract Set<CommonSpringBean> filterComponentScannedStereotypes(@NotNull Module module,
                                                                          @NotNull List<? extends CommonSpringBean> allComponents,
                                                                          @NotNull Set<PsiPackage> psiPackages,
                                                                          boolean useDefaultFilters,
                                                                          @NotNull Set<SpringContextFilter.Exclude> excludeContextFilters,
                                                                          @NotNull Set<SpringContextFilter.Include> includeContextFilters);

  @Nullable
  public abstract SpringStereotypeElement findStereotypeElement(@NotNull PsiClass psiClass);

  /**
   * @deprecated use {@link #processEnabledAnnotations(PsiClass, Processor)}, to remove in IDEA 16
   */
  @NotNull
  @Deprecated
  public abstract Set<PsiClass> getEnabledAnnotations(@NotNull PsiClass classToProcess);

  /**
   * Processes all resolved {@code @Enable...} annotations.
   *
   * @param psiClass  Class with @Enable... annotations to process.
   * @param processor Processor, both pair elements are guaranteed to be non-{@code null}.
   */
  public abstract boolean processEnabledAnnotations(@NotNull PsiClass psiClass,
                                                    @NotNull Processor<Pair<PsiClass, LocalModelDependency>> processor);

  /**
   * Allows extending {@link LocalAnnotationModel} with customized dependent models, e.g. {@code @EnableXYZ}-style models.
   *
   * @param localAnnotationModel Local annotation model to process custom dependent local models for.
   * @param processor            Processor instance.
   * @return Processor result.
   * @since 15
   */
  public abstract boolean processCustomDependentLocalModels(LocalAnnotationModel localAnnotationModel,
                                                            PairProcessor<LocalModel, LocalModelDependency> processor);
}
