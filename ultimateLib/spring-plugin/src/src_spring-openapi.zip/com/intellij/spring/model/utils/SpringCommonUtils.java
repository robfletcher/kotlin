/*
 * Copyright 2000-2015 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.spring.model.utils;

import com.intellij.codeInsight.AnnotationUtil;
import com.intellij.facet.ProjectFacetManager;
import com.intellij.ide.fileTemplates.FileTemplate;
import com.intellij.ide.fileTemplates.FileTemplateUtil;
import com.intellij.jam.JamService;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.module.ModuleUtilCore;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.roots.ProjectRootManager;
import com.intellij.openapi.roots.libraries.JarVersionDetectionUtil;
import com.intellij.openapi.util.Key;
import com.intellij.openapi.util.io.FileUtilRt;
import com.intellij.openapi.util.text.CharFilter;
import com.intellij.psi.*;
import com.intellij.psi.search.FilenameIndex;
import com.intellij.psi.search.GlobalSearchScope;
import com.intellij.psi.search.PackageScope;
import com.intellij.psi.search.ProjectScope;
import com.intellij.psi.util.*;
import com.intellij.spring.constants.SpringAnnotationsConstants;
import com.intellij.spring.constants.SpringConstants;
import com.intellij.spring.facet.SpringFacet;
import com.intellij.spring.facet.SpringSchemaVersion;
import com.intellij.spring.facet.beans.CustomSetting;
import com.intellij.spring.model.jam.stereotype.SpringConfiguration;
import com.intellij.util.SmartList;
import com.intellij.util.containers.ConcurrentFactoryMap;
import com.intellij.util.containers.ContainerUtil;
import com.intellij.util.containers.FactoryMap;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;

public class SpringCommonUtils {

  public static final String SPRING_DELIMITERS = ",; ";

  public static final CharFilter ourFilter = new CharFilter() {

    public boolean accept(char ch) {
      return SPRING_DELIMITERS.indexOf(ch) >= 0;
    }
  };

  @SuppressWarnings("MismatchedQueryAndUpdateOfCollection")
  private static final FactoryMap<String, Key<CachedValue<PsiClass>>> ourLibraryClassKeys =
    new ConcurrentFactoryMap<String, Key<CachedValue<PsiClass>>>() {
      @Nullable
      @Override
      protected Key<CachedValue<PsiClass>> create(String key) {
        return Key.create(key);
      }
    };

  private SpringCommonUtils() {
  }

  public static List<String> tokenize(@NotNull String str) {
    final List<String> list = new SmartList<String>();
    StringTokenizer st = new StringTokenizer(str, SPRING_DELIMITERS);
    while (st.hasMoreTokens()) {
      final String token = st.nextToken().trim();
      if (!token.isEmpty()) {
        list.add(token);
      }
    }
    return list;
  }

  @NotNull
  public static List<PsiType> resolveGenerics(PsiClassType classType) {
    final PsiClassType.ClassResolveResult resolveResult = classType.resolveGenerics();
    final PsiClass psiClass = resolveResult.getElement();
    if (psiClass != null) {
      final PsiSubstitutor substitutor = resolveResult.getSubstitutor();
      List<PsiType> generics = new SmartList<PsiType>();
      for (PsiTypeParameter typeParameter : psiClass.getTypeParameters()) {
        generics.add(substitutor.substitute(typeParameter));
      }
      return generics;
    }
    return Collections.emptyList();
  }

  public static boolean hasSpringLibrary(@NotNull final Project project) {
    return CachedValuesManager.getManager(project).getCachedValue(project, new CachedValueProvider<Boolean>() {
      @Nullable
      @Override
      public Result<Boolean> compute() {
        final boolean foundMarkerClass =
          JavaPsiFacade.getInstance(project).findClass(SpringConstants.BEAN_FACTORY_CLASS,
                                                       ProjectScope.getLibrariesScope(project)) != null;
        return Result.createSingleDependency(foundMarkerClass, ProjectRootManager.getInstance(project));
      }
    });
  }

  public static boolean isAtLeastSpring25(@NotNull final Module module) {
    final String s = JarVersionDetectionUtil.detectJarVersion(SpringConstants.SPRING_VERSION_CLASS, module);
    return s != null && !s.startsWith("1.") && !s.startsWith("2.0") && !s.startsWith("2.1");
  }

  /**
   * Returns whether the given class has {@value SpringAnnotationsConstants#JAVA_SPRING_CONFIGURATION} annotation, <em>excluding</em> meta-annotations.
   *
   * @see #isConfigurationOrMeta(PsiClass)
   */
  public static boolean isConfiguration(@NotNull PsiClass psiClass) {
    return AnnotationUtil.isAnnotated(psiClass, SpringAnnotationsConstants.JAVA_SPRING_CONFIGURATION, false);
  }

  /**
   * Returns whether the given class is <em>(meta-)</em>annotated with {@value SpringAnnotationsConstants#JAVA_SPRING_CONFIGURATION}.
   *
   * @param psiClass Class to check.
   * @return {@code true} if class annotated.
   * @since 15
   */
  public static boolean isConfigurationOrMeta(@NotNull PsiClass psiClass) {
    return JamService.getJamService(psiClass.getProject()).getJamElement(SpringConfiguration.JAM_KEY, psiClass) != null;
  }

  /**
   * Returns whether the given PsiClass (or its inheritors) could possibly be mapped as Spring Bean.
   *
   * @param psiClass PsiClass to check.
   * @return {@code true} if yes.
   * @since 14
   */
  public static boolean isSpringBeanCandidateClass(@Nullable PsiClass psiClass) {
    if (psiClass == null ||
        psiClass instanceof PsiTypeParameter ||
        psiClass.hasModifierProperty(PsiModifier.PRIVATE) ||
        psiClass.isAnnotationType() ||
        psiClass.getQualifiedName() == null ||
        PsiUtil.isLocalOrAnonymousClass(psiClass)) {
      return false;
    }
    return true;
  }

  public static PsiElement createSpringXmlConfigFile(String newName, PsiDirectory directory) throws Exception {
    final Module module = ModuleUtilCore.findModuleForPsiElement(directory);
    final FileTemplate template = getSpringXmlTemplate(module);
    @NonNls final String fileName = FileUtilRt.getExtension(newName).length() == 0 ? newName + ".xml" : newName;
    return FileTemplateUtil.createFromTemplate(template, fileName, null, directory);
  }

  public static FileTemplate getSpringXmlTemplate(final Module... modules) {
    for (Module module : modules) {
      final String version = JarVersionDetectionUtil.detectJarVersion(SpringConstants.SPRING_VERSION_CLASS, module);
      if (version != null) {
        return version.startsWith("1") ?
               SpringSchemaVersion.SPRING_1_DTD.getTemplate(module.getProject()) :
               SpringSchemaVersion.SPRING_SCHEMA.getTemplate(module.getProject());
      }
    }
    return SpringSchemaVersion.SPRING_SCHEMA.getTemplate(modules[0].getProject());
  }

  /**
   * @deprecated use {@link SpringFacet#findSetting(String)}, to remove in IDEA 16
   */
  @Nullable
  public static CustomSetting findSetting(@NotNull Module module, @NotNull String settingName) {
    SpringFacet facet = SpringFacet.getInstance(module);
    if (facet != null) {
      return facet.findSetting(settingName);
    }
    return null;
  }

  @Contract("null -> false")
  public static boolean isSpringConfigured(@Nullable Module module) {
    if (module != null) {
      if (SpringFacet.getInstance(module) != null) return true;
      for (Module dependent : ModuleUtilCore.getAllDependentModules(module)) {
        if (SpringFacet.getInstance(dependent) != null) return true;
      }
      Set<Module> dependencies = ContainerUtil.newHashSet();
      ModuleUtilCore.getDependencies(module, dependencies);
      for (Module dependency : dependencies) {
        if (SpringFacet.getInstance(dependency) != null) return true;
      }
    }

    return false;
  }

  /**
   * Returns true if the given class is a bean candidate, Spring library is present in project and
   * Spring facet in current/dependent module(s) (or at least one in Project for PsiClass located in JAR) exists.
   *
   * @param psiClass Class to check.
   * @return true if all conditions apply
   * @since 14.1
   */
  @Contract("null->false")
  public static boolean isSpringBeanCandidateClassInSpringProject(@Nullable PsiClass psiClass) {
    if (psiClass == null) {
      return false;
    }

    if (!hasSpringLibrary(psiClass.getProject())) {
      return false;
    }

    if (!ProjectFacetManager.getInstance(psiClass.getProject()).hasFacets(SpringFacet.FACET_TYPE_ID)) {
      return false;
    }

    if (!isSpringBeanCandidateClass(psiClass)) {
      return false;
    }

    final Module module = ModuleUtilCore.findModuleForPsiElement(psiClass);
    if (module != null && isSpringConfigured(module)) {
      return true;
    }

    // located in JAR
    return module == null;
  }

  /**
   * Finds all configuration files in {@code META-INF} package with given name in module runtime scope.
   *
   * @param module      Module to search.
   * @param withTests   Include tests scope.
   * @param filename    Config file name.
   * @param psiFileType Expected PsiFile type.
   * @param <T>         Type.
   * @return List of matching files.
   * @since 14.1
   */
  public static <T extends PsiFile> List<T> findConfigFilesInMetaInf(Module module,
                                                                     boolean withTests,
                                                                     String filename,
                                                                     Class<T> psiFileType) {
    final PsiPackage metaInfPackage = JavaPsiFacade.getInstance(module.getProject()).findPackage("META-INF");
    if (metaInfPackage == null) {
      return Collections.emptyList();
    }

    final GlobalSearchScope packageScope = PackageScope.packageScope(metaInfPackage, false);
    final GlobalSearchScope moduleScope = GlobalSearchScope.moduleRuntimeScope(module, withTests);
    final GlobalSearchScope searchScope = moduleScope.intersectWith(packageScope);

    final PsiFile[] configFiles = FilenameIndex.getFilesByName(module.getProject(), filename, searchScope);
    if (configFiles.length == 0) {
      return Collections.emptyList();
    }

    return ContainerUtil.findAll(configFiles, psiFileType);
  }

  /**
   * Returns the <em>library class</em> resolved in runtime production scope of given module, caching the result.
   *
   * @param module    Module.
   * @param className FQN of class located in libraries to find.
   * @return {@code null} if module is {@code null} or class not found.
   * @since 15
   */
  public static PsiClass findLibraryClass(@Nullable final Module module, @NotNull final String className) {
    if (module == null || module.isDisposed()) {
      return null;
    }

    final Project project = module.getProject();

    Key<CachedValue<PsiClass>> clazzKey = ourLibraryClassKeys.get(className);

    return CachedValuesManager.getManager(project).getCachedValue(module, clazzKey, new CachedValueProvider<PsiClass>() {
      @Nullable
      @Override
      public Result<PsiClass> compute() {
        final GlobalSearchScope searchScope = GlobalSearchScope.moduleRuntimeScope(module, false);
        final PsiClass psiClass = JavaPsiFacade.getInstance(project).findClass(className, searchScope);
        return CachedValueProvider.Result.createSingleDependency(psiClass, PsiModificationTracker.JAVA_STRUCTURE_MODIFICATION_COUNT);
      }
    }, false);
  }
}
